# Handoff: Settings Modal — Draba

## Overview

The Settings Modal is a full-featured, role-aware settings interface accessed from the user menu (top-right avatar → Settings). It uses a **sidebar navigation + content panel** layout designed to accommodate future settings sections without structural changes.

Two roles see different content:
- **Regular users** see: Profile, Preferences, Notifications, Security
- **Account Admins** (system-wide) additionally see: Organization, Email / SMTP, Members, Billing

## About the Design Files

HTML design prototype — not production code. Recreate in the existing Draba React codebase using established patterns and design tokens.

## Fidelity

**High-fidelity.** Match exact colors, spacing, typography, and interaction states.

---

## Component: `<SettingsModal>`

### Props

```ts
interface SettingsModalProps {
  isAccountAdmin: boolean;
  onClose:        () => void;
}
```

Rendered via React portal into `document.body`. Backdrop: `rgba(0,0,0,.75)`. Clicking backdrop closes modal.

### Panel container

| Property | Value |
|---|---|
| Width | 900px |
| Height | 640px (fixed) |
| Background | `#161b22` |
| Border | `1px solid #30363d` |
| Border radius | 14px |
| Box shadow | `0 28px 72px rgba(0,0,0,.7)` |
| Layout | Horizontal flex: sidebar (220px fixed) + content area (flex-1) |
| Overflow | hidden on outer; `overflow-y: auto` on sidebar nav + content area independently |

---

## Sidebar

Width: 220px. Background: `#0d1117`. Border-right: `1px solid #30363d`.

### Header (user identity)

```
padding: 0 14px 16px
border-bottom: 1px solid #21262d
margin-bottom: 8px
```

32px circle avatar (member color bg, white initials) + name (13px, 600w) + email (11px, `#484f58`).

### Navigation groups

Padding: `0 8px`. Groups separated by `margin-bottom: 16px`.

**Group label:** 10px, 700w, uppercase, letter-spacing .7px, `#484f58`, padding `0 8px 4px`.

**Nav item button:**
```
display: flex; align-items: center; gap: 9px
padding: 7px 8px; border-radius: 7px; width: 100%
font-size: 13px; border: none; cursor: pointer
```

| State | Background | Text color | Icon color |
|---|---|---|---|
| Default | transparent | `#8b949e` | `#484f58` |
| Active | `#2d333b` | `#e6edf3` (600w) | `#288C9B` (strokeWidth 2) |

**Badge on nav item** (e.g. orphaned count on Members):
```
font-size: 10px; font-weight: 700
background: rgba(249,115,22,.12); color: #F97316
border: 1px solid rgba(249,115,22,.3)
padding: 0 5px; border-radius: 99px; line-height: 16px
```

### Footer

`border-top: 1px solid #21262d; padding: 12px 8px 0; margin-top: 4px`

"Close settings" button — same style as nav item, `#484f58` color + × icon.

---

## Navigation structure

```ts
const NAV_GROUPS = [
  {
    group: 'My Account',
    adminOnly: false,
    items: ['profile', 'preferences', 'notifications', 'security'],
  },
  {
    group: 'Administration',
    adminOnly: true,   // only shown to account admins
    items: ['organization', 'email', 'members-admin', 'billing'],
  },
];
```

Adding a new section = push a new item to the correct group + register its panel component. No structural changes needed.

---

## Content area

`flex: 1; overflow-y: auto; padding: 28px 32px`

Each panel starts with:
```
title: 16px, 700w, #e6edf3, margin-bottom: 4px
subtitle: 13px, #8b949e
```

---

## Shared UI components

### `<FL>` — field label
```
font-size: 11px; font-weight: 600; letter-spacing: .6px
text-transform: uppercase; color: #484f58; margin-bottom: 5px
```
Optional `required` prop adds a red `*`.

### `<SectionDivider>`
Intra-panel section heading: 10px, 700w, uppercase, `#484f58`, `padding: 20px 0 8px`.

### `<Input>`
```
background: #2d333b; border: 1px solid #30363d; border-radius: 7px
padding: 8px 12px; color: #e6edf3; font-size: 13px
```
Password variant: right-side eye toggle button (14px eye/eye-off icon).
Disabled: `opacity: 0.6`, `color: #484f58`.

### `<Select>`
Same bg/border as Input. Custom chevron via `background-image` SVG. `padding-right: 30px`.

### `<Toggle>`
Flex row: label (13px, 500w) + optional sub-label (11px, `#484f58`) + pill toggle (36×20px, accent bg when on, `#373e47` when off, white 16px dot animates left↔right).
Separated by `border-bottom: 1px solid #21262d`.

### `<Btn>`
Variants:

| Variant | Background | Border | Color |
|---|---|---|---|
| default | `#373e47` | `#30363d` | `#8b949e` |
| primary | `#288C9B` | `#288C9B` | `#fff` |
| danger | `rgba(239,68,68,.12)` | `rgba(239,68,68,.3)` | `#EF4444` |
| warn | `rgba(249,115,22,.12)` | `rgba(249,115,22,.3)` | `#F97316` |

Sizes: `md` (padding `7px 14px`, 13px) and `sm` (padding `5px 12px`, 11px).
Disabled: `opacity: 0.6`, `cursor: not-allowed`.

---

## Panel specs

### Profile

Fields: Full name (required), Display name (optional, shown instead of full name), Email address.

Identity badge note: member identity (icon/color) is set per-team via the member panel, not here. Show a read-only preview of the user's current identity with an explanatory note.

Save action: `POST /api/me` with `{ name, displayName, email }`.

---

### Preferences

**Defaults section:**
- Default team — dropdown of teams the user belongs to
- Default timeline — dropdown filtered by selected default team (updates when team changes)

**Regional section:**
- Timezone — IANA timezone selector (full list)
- Date format — `MMM D, YYYY` / `MM/DD/YYYY` / `DD/MM/YYYY` / `YYYY-MM-DD`
- Week starts on — Monday / Sunday (2-column grid with Date format)

**Appearance section:**
- Theme — segmented 3-button: Light / Dark / System
  - Active: `rgba(40,140,155,.12)` bg, `rgba(40,140,155,.28)` border, `#288C9B` text
  - Default: `#2d333b` bg, `#30363d` border, `#8b949e` text

---

### Notifications

Master toggle: "Email notifications" — when off, all sub-toggles dim (`opacity: 0.4`, `pointer-events: none`).

**Activity sub-section:**
- Assigned to me
- Mentioned
- Due soon (48h before end date)
- Overdue (past end date)
- Status changes

**Team sub-section:**
- Team announcements
- Weekly digest (Monday morning)

Save action: `PATCH /api/me/notification-prefs`.

---

### Security

**Change password:**
Three fields: current password, new password (min 8 chars), confirm new password.

Validation:
- New + confirm must match — show `"Passwords don't match"` (11px, `#EF4444`) below confirm field
- Save button disabled until: current is non-empty, new ≥ 8 chars, new === confirm

On success: replace button with `"Password updated successfully"` in `#22C55E` for 3 seconds.

**Sessions:**
Read-only current session card: `background: #2d333b`, shows browser/OS/location + green "Active" badge.

"Sign out all other sessions" — danger variant button.

---

### Organization *(Account Admin)*

Fields: Organization name (required), URL slug (with `app.draba.io/` prefix display, auto-lowercased, strips non-alphanumeric except hyphens).

Logo: placeholder — "coming soon".

**Danger zone** (bottom, separated by full-width border):
```
border: 1px solid rgba(239,68,68,.3)
background: rgba(239,68,68,.12)
border-radius: 9px; padding: 14px 16px
```
Title: "Delete this organization" (13px, 600w, `#EF4444`).
Body: 12px, `#484f58`.
Button: danger sm, opens confirmation dialog.

---

### Email / SMTP *(Account Admin)*

**SMTP server sub-section:**
- Host + Port (2-column grid, port input fixed ~72px wide)
- Username
- Password (masked, eye toggle)

**From address sub-section:**
- From name + From email (2-column grid)

Actions row:
- "Save SMTP settings" (primary)
- "Send test email" button — transitions to "Sending…" for ~2s then "Test email sent!" (success colors) for 3s

Info callout (bottom): `background: #2d333b`, border `#30363d`, `#484f58` text — note about built-in mailer fallback.

---

### Members *(Account Admin)*

**Orphaned member alert** — shown when `orphanedCount > 0`:
```
background: rgba(249,115,22,.12); border: 1px solid rgba(249,115,22,.3)
border-radius: 8; padding: 10px 14px
```
Text: "{N} orphaned member(s) — not assigned to any team." + "View" link that switches to the Orphaned tab.

**Definition of orphaned:** A member account that exists in the system but belongs to zero teams.

**Tabs:** "All ({total})" / "Orphaned ({count})" — segmented control, bg `#2d333b`, active tab bg `#373e47`.

**Search:** Full-width input with search icon, filters by name or email.

**Member row:**
```
padding: 9px 12px; background: #2d333b; border-radius: 8
border: 1px solid #21262d (normal) | rgba(249,115,22,.3) (orphaned)
display: flex; align-items: center; gap: 10
```

Left: 28px circle avatar.
Center: name + optional badges ("No login" for stubs, "Orphaned" for orphaned) + `{email} · {N} teams · Last active: {date}`.
Right: "Assign team" button (warn variant, sm) if orphaned + "Remove" (danger, sm).

Badges: 9px, 700w, uppercase, letter-spacing .3px, warn tint bg + border.

---

### Billing *(Account Admin)*

Placeholder panel. Shows a dashed-border card with a credit-card icon, "Billing management coming soon", and a brief note. No interactive elements.

---

## State

```ts
interface SettingsState {
  activePanel: PanelId;

  // Profile
  name:        string;
  displayName: string;
  email:       string;

  // Preferences
  defaultTeam:     string;
  defaultTimeline: string;
  timezone:        string;
  dateFormat:      string;
  weekStart:       'Monday' | 'Sunday';
  theme:           'Light' | 'Dark' | 'System';

  // Notifications
  notifPrefs: Record<NotifKey, boolean>;

  // Security (no persistent state — form only)

  // Organization (account admin)
  orgName: string;
  orgSlug: string;

  // Email / SMTP (account admin)
  smtp: { host, port, user, pass, fromName, fromEmail };
}
```

---

## Opening flow

User menu (top-right avatar dropdown):
1. Click avatar → dropdown opens
2. Click "Settings" → `setOpen(true)`, dropdown closes
3. Modal opens on **Profile** tab by default

---

## Design tokens

| Token | Value |
|---|---|
| bg0 | `#0d1117` — sidebar bg |
| bg1 | `#161b22` — modal bg |
| bg2 | `#1c2128` — user menu bg |
| bg3 | `#2d333b` — inputs, cards, member rows |
| bg4 | `#373e47` — toggle off, default btn |
| border | `#30363d` |
| border2 | `#21262d` |
| text1 | `#e6edf3` |
| text2 | `#8b949e` |
| text3 | `#484f58` |
| accent | `#288C9B` |
| danger | `#EF4444` |
| warn | `#F97316` |
| success | `#22C55E` |
| promote | `#6366F1` |
| Font | `'Inter'` (align to codebase) |

---

## Related handoffs

- **Identity Widget** — avatar badge shown in sidebar header and profile panel
- **Member Edit Modal** — full member editing (linked from Members admin panel)
- **Team Modal** — team management (linked from Members admin → Assign team)

---

## Files

| File | Description |
|---|---|
| `Settings Modal.html` | Full interactive prototype. "View as" toggle switches between User and Account Admin. Click avatar → Settings or the "Open Settings" button. All 8 panels are interactive. |
