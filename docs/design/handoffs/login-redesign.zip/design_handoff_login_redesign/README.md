# Handoff: Login Page Redesign

## Overview

A redesigned sign-in screen for Draba, inspired by a split-panel layout. The new design replaces the current centered single-card login with a two-panel card: a branded teal panel on the left and a dark form panel on the right. Key UX improvements include floating-label inputs, a password visibility toggle, inline validation, and a loading/success state.

## About the Design Files

The files in this bundle are **HTML design references** — interactive prototypes showing intended look, layout, and behaviour. They are not production code to copy directly. The task is to **recreate this design in Draba's existing Next.js + Tailwind CSS v4 + shadcn/ui codebase**, using its established patterns, components, and auth flows (e.g. NextAuth or similar).

## Fidelity

**High-fidelity.** The prototype uses final colours, typography, spacing, and interaction behaviour. Implement it pixel-accurately using the Draba design system tokens. Where shadcn/ui components overlap (e.g. `<Input>`, `<Button>`), extend or override them to match — don't use their defaults unstyled.

---

## Screen: Sign In

### Layout

The page is full-viewport, dark background (`hsl(210 15% 9%)`), vertically and horizontally centred. A subtle teal radial glow sits behind the card on the left side.

The card is a flex row, `max-width: 860px`, `min-height: 520px`, `border-radius: 16px`, `overflow: hidden`. It has no outer border — just a heavy shadow:

```
box-shadow:
  0 32px 80px -12px rgba(0,0,0,0.55),
  0 0 0 1px rgba(255,255,255,0.06);
```

The card has two children:

| Panel | Width | Background |
|---|---|---|
| Left (brand) | 38% (flex-shrink: 0) | Teal gradient (see below) |
| Right (form) | flex: 1 | `hsl(210 15% 13%)` |

---

### Left Panel — Brand

**Background gradient:**
```css
background: linear-gradient(155deg, #2aa5b8 0%, #1c7585 60%, #145f6e 100%);
```

**Layout:** `display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 20px; padding: 48px 32px; position: relative;`

**Decorative circles (purely visual, `pointer-events: none`):**
- Top-left: `width: 220px; height: 220px; border-radius: 50%; background: rgba(255,255,255,0.07); position: absolute; top: -60px; left: -60px;`
- Bottom-right: `width: 160px; height: 160px; border-radius: 50%; background: rgba(255,255,255,0.05); position: absolute; bottom: -40px; right: -40px;`

**Logo image:** `assets/icon-color.svg`, `width: 88px; height: 88px; filter: drop-shadow(0 4px 16px rgba(0,0,0,0.25));`

**Brand name:**
- Text: `draba`
- `font-size: 28px; font-weight: 700; color: #fff; letter-spacing: -0.01em; text-shadow: 0 2px 8px rgba(0,0,0,0.2);`

**Tagline:** `"Team coordination,\nsimplified."`
- `font-size: 13px; font-weight: 400; color: rgba(255,255,255,0.72); line-height: 1.5; text-align: center; margin-top: 8px;`

---

### Right Panel — Form

**Padding:** `52px 48px`
**Layout:** `display: flex; flex-direction: column; justify-content: center;`

#### Heading block (`margin-bottom: 28px`)

| Element | Value |
|---|---|
| Heading | `"Sign in"` |
| Heading size | `28px`, weight `700`, color `hsl(210 17% 93%)`, `letter-spacing: -0.02em` |
| Subheading | `"Welcome back — sign in to your account."` |
| Subheading size | `14px`, weight `400`, color `hsl(210 15% 52%)` |

#### Inputs (`display: flex; flex-direction: column; gap: 14px; margin-bottom: 24px`)

Both inputs use a **floating label** pattern:

**Outer wrapper:** `position: relative`

**Input container:**
```css
position: relative;
border-radius: 8px;
border: 1px solid <state-dependent>;
background: hsl(210 15% 17%);
transition: border-color 180ms ease, box-shadow 180ms ease;
```

**Border colours by state:**

| State | Border | Box Shadow |
|---|---|---|
| Default | `hsl(210 15% 24%)` | none |
| Focused | `#288C9B` | `0 0 0 3px rgba(40,140,155,0.18)` |
| Error | `#e74c3c` | `0 0 0 3px rgba(231,76,60,0.15)` |

**Floating label:**
```css
position: absolute;
left: 14px;
/* Resting (unfocused, empty): */
top: 50%; transform: translateY(-50%); font-size: 14px; letter-spacing: 0; text-transform: none;
/* Floated (focused or has value): */
top: 8px; transform: none; font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase;
/* Transition: all 160ms cubic-bezier(0.4, 0, 0.2, 1) */
font-weight: 600;
/* Colour: */
/* Default: hsl(210 15% 65%) */
/* Focused: #5BC0DE */
/* Error:   #e74c3c */
```

**Input element:**
```css
width: 100%;
padding: 22px 42px 8px 14px;   /* top padding makes room for floated label */
background: transparent;
border: none;
outline: none;
font-size: 15px;
color: hsl(210 17% 93%);
font-family: 'Open Sans', sans-serif;
line-height: 1.4;
```

**Password visibility toggle** (password field only):
- Positioned `right: 12px`, vertically centred
- Lucide icons: `Eye` / `EyeOff`, `18×18px`, `stroke-width: 1.5`
- Color: `hsl(210 15% 52%)` (muted)
- `background: none; border: none; cursor: pointer;`

**Error message** (shown below input when field is invalid):
- `font-size: 12px; color: #e74c3c; margin-top: 5px; padding-left: 2px;`

**Fields:**
1. Email — `type="email"`, `autoComplete="email"`, label `"Email"`
2. Password — `type="password"`, `autoComplete="current-password"`, label `"Password"`

#### Validation rules

| Field | Rules |
|---|---|
| Email | Required; must match `/\S+@\S+\.\S+/` |
| Password | Required; minimum 6 characters |

Validation fires on submit (not on blur). Errors clear per-field as the user types.

#### Forgot password link (`text-align: right; margin-bottom: 22px; margin-top: -6px`)

- Text: `"Forgot password?"`
- `font-size: 13px; font-weight: 600; color: #5BC0DE`
- Underline on hover

#### Sign in button

```css
width: 100%;
padding: 14px;
border-radius: 8px;
border: none;
background: linear-gradient(135deg, #2aa5b8 0%, #1e8a9c 100%);
color: #fff;
font-size: 15px;
font-weight: 700;
letter-spacing: 0.01em;
box-shadow: 0 4px 20px rgba(40,140,155,0.35);
cursor: pointer;
```

**Hover state:** `opacity: 0.92; transform: translateY(-1px);` (transition `160ms ease`)
**Active/press state:** `transform: scale(0.98);`

**Loading state** (while auth request is in flight):
- Background dims to `hsl(188 40% 35%)` (no gradient)
- Box shadow removed
- Button text replaced with a spinning SVG arc + `"Signing in…"`
- Spinner: Lucide-style arc, `16×16px`, `stroke: rgba(255,255,255,0.8)`, `stroke-width: 2.5`, `animation: spin 0.8s linear infinite`
- Button is `disabled` during loading

#### Sign up link (`margin-top: 24px; text-align: center`)

- Copy: `"Have an invite? "` + `"Create an account"`
- Surrounding text: `13px`, color `hsl(210 15% 52%)`
- Link: color `#5BC0DE`, weight `600`, underline on hover

---

## Success State

After a successful sign-in response, replace the form content with:

- Circular teal checkmark badge:
  - `56×56px`, `border-radius: 50%`
  - `background: rgba(40,140,155,0.15); border: 2px solid #288C9B`
  - Centred Lucide `Check` icon, `24×24px`, `stroke: #288C9B`, `stroke-width: 2.5`
  - `margin: 0 auto 20px`
- Heading: `"You're signed in"` — `20px`, weight `700`, `hsl(210 17% 93%)`
- Body: `"Redirecting to your timeline…"` — `14px`, `hsl(210 15% 52%)`

In production, trigger the Next.js router redirect immediately after the auth response resolves (the success state is a visual bridge while the router navigates).

---

## Interactions & Behaviour Summary

| Action | Behaviour |
|---|---|
| Focus input | Label floats up; teal border + glow |
| Type in input | Label stays floated |
| Blur with value | Label stays floated |
| Blur empty | Label returns to resting position |
| Submit with empty fields | Inline error messages appear per field |
| Submit with invalid email | Email error: `"Enter a valid email"` |
| Submit with short password | Password error: `"Password must be at least 6 characters"` |
| Submit valid form | Button enters loading state; spinner shown |
| Auth success | Form replaced with success state; redirect fires |
| Click eye icon | Toggles password field between `type="password"` / `type="text"` |
| Hover link | Underline appears |

---

## Design Tokens

All values come from the Draba design system (`colors_and_type.css`).

| Token | Value | Usage |
|---|---|---|
| `--color-teal` | `#288C9B` | Focus borders, success state border |
| `--color-teal-light` | `#5BC0DE` | Focused label colour, links |
| Page background | `hsl(210 15% 9%)` | Full-page bg |
| Right panel bg | `hsl(210 15% 13%)` | Form panel |
| Input bg | `hsl(210 15% 17%)` | Input fields |
| Default border | `hsl(210 15% 24%)` | Input borders at rest |
| Text primary | `hsl(210 17% 93%)` | Headings, input values |
| Text muted | `hsl(210 15% 52%)` | Subheadings, placeholder-adjacent copy |
| Text label | `hsl(210 15% 65%)` | Input label at rest |
| Destructive | `#e74c3c` | Error states |
| Font | `'Open Sans'` | All text (weights 300/400/600/700) |

---

## Assets

| File | Usage |
|---|---|
| `assets/icon-color.svg` | Draba logo in left panel — full colour version (teal body, amber pegs). Use on teal/coloured backgrounds only. |

The SVG is included in the handoff zip. In the codebase, reference it from wherever brand assets are stored (e.g. `public/` in Next.js).

---

## Files in this Package

| File | Description |
|---|---|
| `README.md` | This document |
| `Login Page.html` | Full interactive prototype — open in a browser to inspect behaviour |
| `assets/icon-color.svg` | Draba logo asset used in the design |
